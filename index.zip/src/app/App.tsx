import { useState, useEffect, useRef } from "react";
import { motion, useInView } from "motion/react";
import { ArrowUpRight, Github, Linkedin, Mail, Terminal, Cpu, Globe, Code2, Layers, ChevronDown, ExternalLink, Menu, X } from "lucide-react";

const PROJECTS = [
  {
    id: "01",
    title: "Neural Interface OS",
    category: "UI/UX Design",
    year: "2024",
    description: "Operating system interface designed for brain-computer interaction. Spatial computing paradigms translated to 2D screens.",
    tags: ["Spatial UI", "Motion", "Systems Design"],
    color: "#00e5ff",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=500&fit=crop&auto=format",
  },
  {
    id: "02",
    title: "Quantum Dashboard",
    category: "Frontend Engineering",
    year: "2024",
    description: "Real-time data visualization for quantum computing metrics. 60fps rendering of 10M+ data points with WebGL pipelines.",
    tags: ["WebGL", "React", "D3.js"],
    color: "#7c3aff",
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&h=500&fit=crop&auto=format",
  },
  {
    id: "03",
    title: "Hyperion Protocol",
    category: "Full Stack",
    year: "2023",
    description: "Decentralized mesh network management console. End-to-end encrypted communication infrastructure for distributed teams.",
    tags: ["Node.js", "WebSockets", "Crypto"],
    color: "#00e5ff",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&h=500&fit=crop&auto=format",
  },
  {
    id: "04",
    title: "Axiom Design System",
    category: "Design Systems",
    year: "2023",
    description: "Component library and design token architecture for a Series C fintech. 140+ components, full dark/light parity.",
    tags: ["Figma", "Storybook", "Tokens"],
    color: "#7c3aff",
    image: "https://images.unsplash.com/photo-1617042375876-a13e36732a04?w=800&h=500&fit=crop&auto=format",
  },
];

const SKILLS = [
  { name: "Interface Design", level: 96, category: "Design" },
  { name: "React / TypeScript", level: 94, category: "Engineering" },
  { name: "Motion & Animation", level: 89, category: "Design" },
  { name: "WebGL / Three.js", level: 78, category: "Engineering" },
  { name: "Design Systems", level: 92, category: "Design" },
  { name: "Node.js / APIs", level: 85, category: "Engineering" },
];

function GridBackground() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0,229,255,1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,229,255,1) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />
      <div
        className="absolute inset-0 opacity-30"
        style={{
          background: "radial-gradient(ellipse 80% 60% at 50% -10%, rgba(124,58,255,0.15) 0%, transparent 70%)",
        }}
      />
      <div
        className="absolute inset-0 opacity-20"
        style={{
          background: "radial-gradient(ellipse 60% 40% at 80% 80%, rgba(0,229,255,0.08) 0%, transparent 60%)",
        }}
      />
    </div>
  );
}

function GlitchText({ text, className }: { text: string; className?: string }) {
  const [glitching, setGlitching] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setGlitching(true);
      setTimeout(() => setGlitching(false), 150);
    }, 4000 + Math.random() * 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <span
      className={`relative inline-block ${className || ""}`}
      style={{
        animation: glitching ? "glitch 0.15s steps(2) forwards" : undefined,
      }}
    >
      {text}
      <style>{`
        @keyframes glitch {
          0% { clip-path: inset(20% 0 60% 0); transform: translate(-4px, 0); color: #7c3aff; }
          25% { clip-path: inset(60% 0 10% 0); transform: translate(4px, 0); color: #00e5ff; }
          50% { clip-path: inset(40% 0 40% 0); transform: translate(-2px, 1px); color: #ff3366; }
          75% { clip-path: inset(10% 0 70% 0); transform: translate(2px, -1px); color: #7c3aff; }
          100% { clip-path: inset(0); transform: translate(0); color: inherit; }
        }
      `}</style>
    </span>
  );
}

function ScanLine() {
  return (
    <div
      className="fixed inset-0 pointer-events-none z-50 opacity-[0.025]"
      style={{
        backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.3) 2px, rgba(0,0,0,0.3) 4px)",
      }}
    />
  );
}

function Nav({ activeSection }: { activeSection: string }) {
  const [open, setOpen] = useState(false);
  const links = ["work", "about", "skills", "contact"];

  return (
    <nav className="fixed top-0 left-0 right-0 z-40">
      <div
        className="border-b border-border"
        style={{ background: "rgba(3,4,10,0.85)", backdropFilter: "blur(12px)" }}
      >
        <div className="max-w-7xl mx-auto px-6 h-14 flex items-center justify-between">
          <a href="#hero" className="font-mono text-sm tracking-[0.2em] text-primary font-medium">
            <span className="opacity-50">{"// "}</span>USER_PLACEHOLDER
          </a>

          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <a
                key={link}
                href={`#${link}`}
                className="font-mono text-xs tracking-[0.15em] uppercase transition-colors duration-200"
                style={{
                  color: activeSection === link ? "#00e5ff" : "#5a6a8a",
                }}
              >
                {link}
              </a>
            ))}
            <a
              href="mailto:alex@nova.dev"
              className="flex items-center gap-2 px-4 py-1.5 border border-primary/40 font-mono text-xs tracking-[0.12em] text-primary hover:bg-primary/10 transition-colors"
            >
              HIRE ME <ArrowUpRight size={12} />
            </a>
          </div>

          <button
            className="md:hidden text-muted-foreground hover:text-primary transition-colors"
            onClick={() => setOpen(!open)}
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {open && (
        <div
          className="md:hidden border-b border-border"
          style={{ background: "rgba(3,4,10,0.95)", backdropFilter: "blur(12px)" }}
        >
          {links.map((link) => (
            <a
              key={link}
              href={`#${link}`}
              onClick={() => setOpen(false)}
              className="block px-6 py-3 font-mono text-xs tracking-[0.15em] uppercase border-b border-border/30"
              style={{ color: activeSection === link ? "#00e5ff" : "#5a6a8a" }}
            >
              {link}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
}

function Hero() {
  const [typedIndex, setTypedIndex] = useState(0);
  const subtitle = "INTERFACE ARCHITECT  ·  CREATIVE ENGINEER";

  useEffect(() => {
    if (typedIndex < subtitle.length) {
      const t = setTimeout(() => setTypedIndex(typedIndex + 1), 40);
      return () => clearTimeout(t);
    }
  }, [typedIndex, subtitle.length]);

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col justify-center pt-14"
    >
      <div className="max-w-7xl mx-auto px-6 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-12 items-end pb-20">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="font-mono text-xs tracking-[0.3em] text-primary/60 mb-6 flex items-center gap-3"
            >
              <span className="w-8 h-px bg-primary/40" />
              PORTFOLIO 2024 — AVAILABLE FOR WORK
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="font-['Rajdhani'] font-700 leading-[0.9] tracking-[-0.02em] mb-6"
              style={{ fontSize: "clamp(4rem, 12vw, 9rem)", fontWeight: 700 }}
            >
              <GlitchText text="USER" className="text-foreground" />
              <br />
              <span style={{ color: "#00e5ff", WebkitTextStroke: "0px" }}>PLACEHOLDER</span>
            </motion.h1>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.0 }}
              className="font-mono text-sm tracking-[0.2em] text-muted-foreground mb-10 h-6"
            >
              {subtitle.slice(0, typedIndex)}
              <span className="animate-pulse text-primary">|</span>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2 }}
              className="flex flex-wrap gap-4"
            >
              <a
                href="#work"
                className="group flex items-center gap-3 px-6 py-3 font-mono text-xs tracking-[0.15em] text-background bg-primary hover:bg-primary/90 transition-all"
              >
                VIEW WORK
                <ArrowUpRight size={14} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>
              <a
                href="#contact"
                className="flex items-center gap-3 px-6 py-3 font-mono text-xs tracking-[0.15em] text-primary border border-primary/30 hover:border-primary/60 hover:bg-primary/5 transition-all"
              >
                GET IN TOUCH
              </a>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="hidden lg:grid grid-cols-2 gap-3 text-right"
          >
            {[
              { n: "47", label: "Projects\nDelivered" },
              { n: "6+", label: "Years\nExperience" },
              { n: "23", label: "Clients\nWorldwide" },
              { n: "99", label: "Client\nSatisfaction" },
            ].map(({ n, label }) => (
              <div key={n} className="border border-border p-4 bg-card/40 min-w-[100px]">
                <div className="font-['Rajdhani'] text-3xl font-bold text-primary leading-none mb-1">{n}</div>
                <div
                  className="font-mono text-[10px] leading-tight text-muted-foreground tracking-[0.12em] whitespace-pre-line"
                >
                  {label}
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <span className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground">SCROLL</span>
        <ChevronDown size={14} className="text-primary animate-bounce" />
      </div>

      <div
        className="absolute bottom-0 left-0 right-0 h-px"
        style={{ background: "linear-gradient(90deg, transparent, rgba(0,229,255,0.3), transparent)" }}
      />
    </section>
  );
}

function ProjectCard({ project, index }: { project: typeof PROJECTS[0]; index: number }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  const [hovered, setHovered] = useState(false);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="group relative border border-border hover:border-primary/30 transition-all duration-500 overflow-hidden cursor-pointer"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="relative overflow-hidden aspect-[16/9] bg-secondary">
        <img
          src={project.image}
          alt={project.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-60 group-hover:opacity-80"
        />
        <div
          className="absolute inset-0"
          style={{
            background: `linear-gradient(135deg, ${project.color}22 0%, transparent 60%)`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />

        <div className="absolute top-4 left-4 font-mono text-[10px] tracking-[0.2em] text-muted-foreground">
          {project.id}
        </div>
        <div className="absolute top-4 right-4 font-mono text-[10px] tracking-[0.2em] text-muted-foreground">
          {project.year}
        </div>
      </div>

      <div className="p-6">
        <div className="font-mono text-[10px] tracking-[0.2em] mb-2" style={{ color: project.color }}>
          {project.category.toUpperCase()}
        </div>
        <h3 className="font-['Rajdhani'] text-2xl font-bold text-foreground mb-3 leading-tight">
          {project.title}
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed mb-4 font-['Inter']">
          {project.description}
        </p>
        <div className="flex flex-wrap gap-2">
          {project.tags.map((tag) => (
            <span
              key={tag}
              className="font-mono text-[10px] tracking-[0.12em] px-2 py-1 border"
              style={{
                borderColor: `${project.color}30`,
                color: project.color,
                background: `${project.color}08`,
              }}
            >
              {tag}
            </span>
          ))}
        </div>
      </div>

      <div
        className="absolute bottom-0 left-0 right-0 h-px transition-opacity duration-300"
        style={{
          background: `linear-gradient(90deg, transparent, ${project.color}60, transparent)`,
          opacity: hovered ? 1 : 0,
        }}
      />

      <div
        className="absolute top-4 right-16 w-6 h-6 border border-current flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
        style={{ color: project.color }}
      >
        <ExternalLink size={10} />
      </div>
    </motion.div>
  );
}

function Work() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });

  return (
    <section id="work" className="py-32 relative">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          ref={ref}
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5 }}
          className="flex items-end justify-between mb-16"
        >
          <div>
            <div className="font-mono text-[10px] tracking-[0.3em] text-primary/60 mb-4 flex items-center gap-3">
              <span className="w-6 h-px bg-primary/40" />
              SELECTED WORK
            </div>
            <h2 className="font-['Rajdhani'] font-bold leading-none" style={{ fontSize: "clamp(2.5rem, 6vw, 5rem)" }}>
              PROJECTS
            </h2>
          </div>
          <a
            href="#contact"
            className="hidden md:flex items-center gap-2 font-mono text-xs tracking-[0.12em] text-muted-foreground hover:text-primary transition-colors"
          >
            ALL PROJECTS <ArrowUpRight size={12} />
          </a>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {PROJECTS.map((project, i) => (
            <ProjectCard key={project.id} project={project} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function About() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="py-32 border-t border-border relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.4fr] gap-16 items-center">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
          >
            <div className="font-mono text-[10px] tracking-[0.3em] text-primary/60 mb-4 flex items-center gap-3">
              <span className="w-6 h-px bg-primary/40" />
              ABOUT
            </div>
            <h2 className="font-['Rajdhani'] font-bold leading-none mb-8" style={{ fontSize: "clamp(2.5rem, 6vw, 5rem)" }}>
              ABOUT ME
            </h2>

            <div className="relative aspect-[3/4] max-w-xs border border-border overflow-hidden">
              <img
                src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='500' height='660'%3E%3Crect width='500' height='660' fill='%23374151'/%3E%3Ccircle cx='250' cy='220' r='90' fill='%234B5563'/%3E%3Cellipse cx='250' cy='500' rx='160' ry='130' fill='%234B5563'/%3E%3C/svg%3E"
                alt="User Placeholder"
                className="w-full h-full object-cover opacity-70"
              />
              <div
                className="absolute inset-0"
                style={{ background: "linear-gradient(180deg, transparent 50%, rgba(3,4,10,0.8) 100%)" }}
              />
              <div
                className="absolute inset-0 opacity-20"
                style={{
                  backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(0,229,255,0.15) 3px, rgba(0,229,255,0.15) 4px)",
                }}
              />
              <div className="absolute bottom-4 left-4 right-4">
                <div className="font-['Rajdhani'] text-xl font-bold text-foreground">User Placeholder</div>
                <div className="font-mono text-[10px] tracking-[0.15em] text-primary">INTERFACE ARCHITECT</div>
              </div>
              <div
                className="absolute top-0 left-0 right-0 h-px"
                style={{ background: "linear-gradient(90deg, transparent, rgba(0,229,255,0.5), transparent)" }}
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.15 }}
          >
            <p className="text-lg leading-relaxed text-foreground/80 font-['Inter'] mb-6 font-light">
              I design and engineer digital experiences that live at the intersection of systems thinking and aesthetic precision. Six years building products that ship — from zero-to-one MVPs to scaled platforms serving millions.
            </p>

            <p className="text-base leading-relaxed text-muted-foreground font-['Inter'] mb-10">
              My practice spans the full spectrum: defining interaction models at the whiteboard, architecting component systems in Figma, and shipping production React with the engineers. I believe the best interfaces feel inevitable — you can't imagine them being any other way.
            </p>

            <div className="grid grid-cols-3 gap-4 mb-10">
              {[
                { icon: <Code2 size={16} />, label: "Engineering" },
                { icon: <Layers size={16} />, label: "Systems" },
                { icon: <Globe size={16} />, label: "Web" },
              ].map(({ icon, label }) => (
                <div key={label} className="border border-border p-4 flex flex-col items-center gap-2 text-center hover:border-primary/30 transition-colors">
                  <span className="text-primary">{icon}</span>
                  <span className="font-mono text-[10px] tracking-[0.15em] text-muted-foreground">{label.toUpperCase()}</span>
                </div>
              ))}
            </div>

            <div className="flex gap-4">
              {[
                { icon: <Github size={16} />, label: "GitHub" },
                { icon: <Linkedin size={16} />, label: "LinkedIn" },
                { icon: <Mail size={16} />, label: "Email" },
              ].map(({ icon, label }) => (
                <a
                  key={label}
                  href="#contact"
                  className="flex items-center gap-2 font-mono text-xs tracking-[0.1em] text-muted-foreground hover:text-primary transition-colors"
                >
                  {icon} {label}
                </a>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function SkillBar({ skill, index }: { skill: typeof SKILLS[0]; index: number }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      className="group"
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-3">
          <span
            className="font-mono text-[9px] tracking-[0.15em] px-1.5 py-0.5"
            style={{
              color: skill.category === "Design" ? "#00e5ff" : "#7c3aff",
              border: `1px solid ${skill.category === "Design" ? "#00e5ff30" : "#7c3aff30"}`,
              background: skill.category === "Design" ? "#00e5ff08" : "#7c3aff08",
            }}
          >
            {skill.category.toUpperCase()}
          </span>
          <span className="font-['Rajdhani'] font-semibold text-foreground text-base">{skill.name}</span>
        </div>
        <span className="font-mono text-xs text-muted-foreground">{skill.level}%</span>
      </div>
      <div className="h-px bg-border relative overflow-hidden">
        <motion.div
          className="h-full absolute left-0 top-0"
          initial={{ width: 0 }}
          animate={inView ? { width: `${skill.level}%` } : {}}
          transition={{ duration: 1, delay: index * 0.08 + 0.3, ease: "easeOut" }}
          style={{
            background: skill.category === "Design"
              ? "linear-gradient(90deg, #00e5ff, #00e5ff80)"
              : "linear-gradient(90deg, #7c3aff, #7c3aff80)",
          }}
        />
      </div>
    </motion.div>
  );
}

function Skills() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });

  return (
    <section id="skills" className="py-32 border-t border-border">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_1fr] gap-20">
          <div>
            <motion.div
              ref={ref}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5 }}
            >
              <div className="font-mono text-[10px] tracking-[0.3em] text-primary/60 mb-4 flex items-center gap-3">
                <span className="w-6 h-px bg-primary/40" />
                CAPABILITIES
              </div>
              <h2 className="font-['Rajdhani'] font-bold leading-none mb-8" style={{ fontSize: "clamp(2.5rem, 6vw, 5rem)" }}>
                SKILLS
              </h2>
              <p className="text-muted-foreground font-['Inter'] text-sm leading-relaxed">
                Fluent across the design-to-production pipeline. I work where the gap between design and engineering is smallest — shipping interfaces that are both considered and correct.
              </p>
            </motion.div>
          </div>

          <div className="flex flex-col gap-6">
            {SKILLS.map((skill, i) => (
              <SkillBar key={skill.name} skill={skill} index={i} />
            ))}
          </div>
        </div>

        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: <Terminal size={20} />, title: "CLI Tooling", desc: "Bash, Node.js scripts, automation" },
            { icon: <Cpu size={20} />, title: "Performance", desc: "Core Web Vitals, Lighthouse 100" },
            { icon: <Code2 size={20} />, title: "Architecture", desc: "Monorepos, micro-frontends" },
            { icon: <Layers size={20} />, title: "Tokens", desc: "Design-to-code token pipelines" },
          ].map(({ icon, title, desc }) => (
            <motion.div
              key={title}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4 }}
              className="border border-border p-5 hover:border-primary/25 transition-colors group"
            >
              <span className="text-primary mb-3 block group-hover:scale-110 transition-transform origin-left">{icon}</span>
              <div className="font-['Rajdhani'] font-semibold text-foreground mb-1">{title}</div>
              <div className="font-['Inter'] text-xs text-muted-foreground">{desc}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="contact" className="py-32 border-t border-border">
      <div className="max-w-7xl mx-auto px-6">
        <div className="max-w-2xl">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7 }}
          >
            <div className="font-mono text-[10px] tracking-[0.3em] text-primary/60 mb-4 flex items-center gap-3">
              <span className="w-6 h-px bg-primary/40" />
              CONTACT
            </div>
            <h2 className="font-['Rajdhani'] font-bold leading-none mb-6" style={{ fontSize: "clamp(2.5rem, 8vw, 7rem)" }}>
              LET&apos;S BUILD<br />
              <span style={{ color: "#00e5ff" }}>SOMETHING.</span>
            </h2>
            <p className="text-muted-foreground font-['Inter'] text-base leading-relaxed mb-10">
              Currently taking on new projects for Q1 2025. If you&apos;re building something that demands the intersection of design excellence and engineering rigor — let&apos;s talk.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <a
                href="mailto:alex@nova.dev"
                className="group flex items-center gap-3 px-6 py-4 bg-primary text-background font-mono text-xs tracking-[0.15em] hover:bg-primary/90 transition-colors"
              >
                <Mail size={14} />
                alex@nova.dev
                <ArrowUpRight size={12} className="ml-auto group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>
              <a
                href="#"
                className="group flex items-center gap-3 px-6 py-4 border border-border font-mono text-xs tracking-[0.15em] text-foreground hover:border-primary/40 hover:bg-primary/5 transition-all"
              >
                <Linkedin size={14} />
                LinkedIn
                <ArrowUpRight size={12} className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </a>
              <a
                href="#"
                className="group flex items-center gap-3 px-6 py-4 border border-border font-mono text-xs tracking-[0.15em] text-foreground hover:border-primary/40 hover:bg-primary/5 transition-all"
              >
                <Github size={14} />
                GitHub
                <ArrowUpRight size={12} className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </a>
            </div>

            <div className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground">
              BASED IN SAN FRANCISCO, CA · AVAILABLE WORLDWIDE
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border py-8">
      <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <span className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground">
          <span className="opacity-50">{"// "}</span>USER_PLACEHOLDER · PORTFOLIO 2024
        </span>
        <span className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground">
          DESIGNED & BUILT WITH PRECISION
        </span>
      </div>
    </footer>
  );
}

export default function App() {
  const [activeSection, setActiveSection] = useState("hero");

  useEffect(() => {
    const sections = ["hero", "work", "about", "skills", "contact"];
    const observers: IntersectionObserver[] = [];

    sections.forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      const obs = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) setActiveSection(id);
        },
        { threshold: 0.3 }
      );
      obs.observe(el);
      observers.push(obs);
    });

    return () => observers.forEach((o) => o.disconnect());
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground relative" style={{ fontFamily: "'Inter', sans-serif" }}>
      <ScanLine />
      <GridBackground />
      <Nav activeSection={activeSection} />
      <main className="relative z-10">
        <Hero />
        <Work />
        <About />
        <Skills />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
